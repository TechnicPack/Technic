#!/bin/sh
java -Xmx3G -Xms2G -jar TekkitLite.jar nogui