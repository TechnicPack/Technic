#!/bin/sh
java -Xmx3G -Xms2G -jar Voltz.jar nogui