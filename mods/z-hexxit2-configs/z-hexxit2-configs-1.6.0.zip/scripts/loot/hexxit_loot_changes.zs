#priority 1

import loottweaker.LootTweaker;
import loottweaker.vanilla.loot.LootTable;
import loottweaker.vanilla.loot.LootPool;
import loottweaker.vanilla.loot.Functions;
import loottweaker.vanilla.loot.Conditions;

// Improve drops from cows
LootTweaker.getTable("minecraft:entities/cow").getPool("main").setRolls(2, 2);

// Remove old Bird's Nests loot
LootTweaker.getTable("birdsnests:nest_loot").removePool("nest_loot");

// Remove excessive Elementary Staffs loot
LootTweaker.getTable("cqrepoured:chests/food").removePool("loot");
LootTweaker.getTable("cqrepoured:chests/equipment").removePool("loot");
LootTweaker.getTable("cqrepoured:chests/clutter").removePool("loot");
LootTweaker.getTable("quark:chests/pirate_chest").removePool("loot");
LootTweaker.getTable("mod_lavacow:chests/cemetery_chest").removePool("loot");
LootTweaker.getTable("mod_lavacow:chests/desert_tomb_chest").removePool("loot");

// Remove excessive Growthcraft hops loot
LootTweaker.getTable("minecraft:chests/simple_dungeon").removePool("growthcraft_hops:loot_table_simple_dungeon");
LootTweaker.getTable("minecraft:chests/abandoned_mineshaft").removePool("growthcraft_hops:loot_table_simple_dungeon");

// Remove disabled items from loot
LootTweaker.getTable("mod_lavacow:chests/cemetery_chest").getPool("main").removeEntry("mod_lavacow:parasite_item");
LootTweaker.getTable("mod_lavacow:chests/desert_tomb_chest").getPool("main").removeEntry("mod_lavacow:parasite_item");
LootTweaker.getTable("mod_lavacow:entities/bosses/skeleton_king").getPool("rare").removeEntry("mod_lavacow:piranhalauncher");

// Add (Stained) King's Crown to Desert Pyramid loottable
LootTweaker.getTable("minecraft:chests/desert_pyramid").getPool("thp3").addItemEntry(<mod_lavacow:kings_crown:0>, 40, 1, [Functions.setCount(1, 1)], []);

// Add Filch Lizard loot
val filchLizardSpawnPool = LootTweaker.getTable("mocreatures:entities/filch_lizard/filch_lizard_spawn").getPool("filchlizard_spawnitem");
filchLizardSpawnPool.addItemEntry(<birdsnests:birdsnest>, 4, "birdsnests:birdsnest");
filchLizardSpawnPool.addItemEntry(<hexxitworld:material:1>, 6, "hexxitworld:material:1");
filchLizardSpawnPool.addItemEntry(<combustfish:bone_fish>, 6, "combustfish:bone_fish");
filchLizardSpawnPool.addItemEntry(<hexxitworld:mystic_seed>, 1, "hexxitworld:mystic_seed");
filchLizardSpawnPool.addItemEntry(<hexxitgear:refresher_shard>, 2, "hexxitgear:refresher_shard");
filchLizardSpawnPool.addItemEntry(<hexxitworld:material:2>, 1, "hexxitworld:material:2");
filchLizardSpawnPool.addItemEntry(<cqrepoured:feather_golden>, 1, "cqrepoured:feather_golden");
filchLizardSpawnPool.addItemEntry(<mod_lavacow:tooth_dagger>, 4, "mod_lavacow:tooth_dagger");
filchLizardSpawnPool.addItemEntry(<mocreatures:turkeyraw>, 2, "mocreatures:turkeyraw");
filchLizardSpawnPool.addItemEntry(<minecraft:rabbit>, 6, "minecraft:rabbit");
filchLizardSpawnPool.addItemEntry(<mocreatures:ratraw>, 6, "mocreatures:ratraw");
filchLizardSpawnPool.addItemEntry(<mod_lavacow:hyphae>, 3, "mod_lavacow:hyphae");
filchLizardSpawnPool.addItemEntry(<mod_lavacow:cactus_thorn>, 8, "mod_lavacow:cactus_thorn");
filchLizardSpawnPool.addItemEntry(<mod_lavacow:basicbomb>, 3, "mod_lavacow:basicbomb");
filchLizardSpawnPool.addItemEntry(<mowziesmobs:dart>, 4, "mowziesmobs:dart");
filchLizardSpawnPool.addItemEntry(<mowziesmobs:blowgun>, 6, "mowziesmobs:blowgun");
filchLizardSpawnPool.addItemEntry(<statues:palette>, 2, "statues:palette");
filchLizardSpawnPool.addItemEntry(<mocreatures:ancientsilverscrap>, 4, "mocreatures:ancientsilverscrap");
filchLizardSpawnPool.addItemEntry(<mocreatures:ratburger>, 3, "mocreatures:ratburger");
filchLizardSpawnPool.addItemEntry(<openblocks:cursor>, 1, "openblocks:cursor");
filchLizardSpawnPool.addItemEntry(<hexxitworld:reed_pipes>, 3, "hexxitworld:reed_pipes");
filchLizardSpawnPool.addItemEntry(<hexxitworld:bad_bow>, 3, "hexxitworld:bad_bow");
filchLizardSpawnPool.addItemEntry(<harkenscythe:soul_cookie>, 5, "harkenscythe:soul_cookie");
filchLizardSpawnPool.addItemEntry(<harkenscythe:blood_essence>, 3, "harkenscythe:blood_essence");
filchLizardSpawnPool.addItemEntry(<hexxitworld:fortune_cookie>, 4, "hexxitworld:fortune_cookie");
val filchLizardStealTable = LootTweaker.getTable("mocreatures:entities/filch_lizard/filch_lizard_steal");
filchLizardStealTable.addPool("hexxit1", 1, 1, 0, 0).addItemEntry(<birdsnests:birdsnest>, 1, "birdsnests:birdsnest");
filchLizardStealTable.addPool("hexxit2", 1, 1, 0, 0).addItemEntry(<hexxitworld:material:1>, 1, "hexxitworld:material:1");
filchLizardStealTable.addPool("hexxit3", 1, 1, 0, 0).addItemEntry(<hexxitgear:hexbiscus>, 1, "hexxitgear:hexbiscus");
filchLizardStealTable.addPool("hexxit4", 1, 1, 0, 0).addItemEntry(<combustfish:bone_fish>, 2, "combustfish:bone_fish");
filchLizardStealTable.addPool("hexxit5", 1, 1, 0, 0).addItemEntry(<nyx:fallen_star>, 1, "nyx:fallen_star");
filchLizardStealTable.addPool("hexxit6", 1, 1, 0, 0).addItemEntry(<hexxitworld:mystic_seed>, 1, "hexxitworld:mystic_seed");
filchLizardStealTable.addPool("hexxit7", 1, 1, 0, 0).addItemEntry(<hexxitgear:refresher_shard>, 1, "hexxitgear:refresher_shard");
filchLizardStealTable.addPool("hexxit8", 1, 1, 0, 0).addItemEntry(<hexxitworld:material:2>, 1, "hexxitworld:material:2");
filchLizardStealTable.addPool("hexxit9", 1, 1, 0, 0).addItemEntry(<cqrepoured:feather_golden>, 1, "cqrepoured:feather_golden");
filchLizardStealTable.addPool("hexxit10", 1, 1, 0, 0).addItemEntry(<mod_lavacow:tooth_dagger>, 1, "mod_lavacow:tooth_dagger");
filchLizardStealTable.addPool("hexxit11", 1, 1, 0, 0).addItemEntry(<hexxitgear:hexical_essence>, 1, "hexxitgear:hexical_essence");
filchLizardStealTable.addPool("hexxit12", 1, 1, 0, 0).addItemEntry(<tconstruct:materials:16>, 1, "tconstruct:materials:16");
filchLizardStealTable.addPool("hexxit13", 1, 1, 0, 0).addItemEntry(<tconstruct:materials:9>, 1, "tconstruct:materials:9");
filchLizardStealTable.addPool("hexxit14", 1, 1, 0, 0).addItemEntry(<minecraft:golden_apple>, 1, "minecraft:golden_apple");
filchLizardStealTable.addPool("hexxit15", 1, 1, 0, 0).addItemEntry(<minecraft:golden_apple:1>, 1, "minecraft:golden_apple:1");
filchLizardStealTable.addPool("hexxit16", 1, 1, 0, 0).addItemEntry(<xreliquary:holy_hand_grenade>, 1, "xreliquary:holy_hand_grenade");
filchLizardStealTable.addPool("hexxit17", 1, 1, 0, 0).addItemEntry(<mocreatures:turkeyraw>, 1, "mocreatures:turkeyraw");
filchLizardStealTable.addPool("hexxit18", 1, 1, 0, 0).addItemEntry(<minecraft:rabbit>, 1, "minecraft:rabbit");
filchLizardStealTable.addPool("hexxit19", 1, 1, 0, 0).addItemEntry(<mocreatures:ratraw>, 1, "mocreatures:ratraw");
filchLizardStealTable.addPool("hexxit20", 1, 1, 0, 0).addItemEntry(<nyx:celestial_emblem>, 1, "nyx:celestial_emblem");
filchLizardStealTable.addPool("hexxit21", 1, 1, 0, 0).addItemEntry(<minecraft:diamond>, 1, "minecraft:diamond");
filchLizardStealTable.addPool("hexxit22", 1, 1, 0, 0).addItemEntry(<minecraft:gold_ingot>, 1, "minecraft:gold_ingot");
filchLizardStealTable.addPool("hexxit23", 1, 1, 0, 0).addItemEntry(<minecraft:emerald>, 1, "minecraft:emerald");
filchLizardStealTable.addPool("hexxit24", 1, 1, 0, 0).addItemEntry(<hexxitworld:milk_chocolate>, 1, "hexxitworld:milk_chocolate");

// Replace mob drops with ore dictionary item
val ghostPool = LootTweaker.getTable("ancientbeasts:entities/ghost").getPool("ancientbeasts:Ghost");
ghostPool.removeEntry("ancientbeasts:ectoplasm");
ghostPool.addItemEntry(<mod_lavacow:ectoplasm>, 1, 0, [Functions.setCount(0, 2), Functions.lootingEnchantBonus(0, 3, 5)], []);
val vesselPool = LootTweaker.getTable("ancientbeasts:entities/vessel").getPool("ancientbeasts:Vessel0");
vesselPool.removeEntry("ancientbeasts:ectoplasm");
vesselPool.addItemEntry(<mod_lavacow:ectoplasm>, 1, 0, [Functions.setCount(0, 2), Functions.lootingEnchantBonus(0, 3, 5)], []);

// Remove loot from disabled mobs so it doesn't show up (thanks to JER support)
LootTweaker.getTable("mod_lavacow:entities/weta").clear();
LootTweaker.getTable("mod_lavacow:entities/pingu").clear();
LootTweaker.getTable("mod_lavacow:entities/piranha").clear();
LootTweaker.getTable("mod_lavacow:entities/swarmer").clear();
LootTweaker.getTable("mod_lavacow:entities/undead_swine").clear();
LootTweaker.getTable("mod_lavacow:entities/mycosis").clear();
LootTweaker.getTable("mod_lavacow:entities/boneworm").clear();
LootTweaker.getTable("mod_lavacow:entities/soulworm").clear();
LootTweaker.getTable("mod_lavacow:entities/frigid").clear();
LootTweaker.getTable("mod_lavacow:entities/vespa").clear();
LootTweaker.getTable("mod_lavacow:entities/parasite").clear();
LootTweaker.getTable("mod_lavacow:entities/avaton").removePool("rare");